//Java Program to Print Multiplication Table
import java.io.*;
import java.util.*;
import java.net.*;
public class Assignment6 {
     public static void main(String[] args){
         Scanner sc=new Scanner(System.in);
         System.out.print("enter value of n for which u want the table:");
         int n1=sc.nextInt();
         for(int i=1;i<=10;i++){
             System.out.println(n1+ "*"+ i+ "="+(n1*i));
         }
     }
    
}
