//Take 3 inputs from user and check :
//all are equal
//any of two are equal
//( use && || ) 

import java.io.*;
import java.util.*;
import java.net.*;
public class Assignment3 {
    public static void main(String[] args){
         Scanner sc=new Scanner(System.in);
         System.out.print("enter a 1st number:");
         int n1=sc.nextInt();
         System.out.print("enter a 2nd number:");
         int n2=sc.nextInt();
         System.out.print("enter a 3rd number:");
         int n3=sc.nextInt();
         if(n1==n2 && n2==n3 ){
               System.out.print("all are equal");  
             }
         if(n1==n2 || n1==n3 || n3==n2){
               System.out.print("any two numbers are equal");  
             }
         
    
 }
}
