//Define two methods to print the maximum and the minimum number respectively among three numbers entered by the user.

import java.io.*;
import java.util.*;
import java.net.*;
public class Assignment8 {
     public static void main(String[] args){
          Scanner sc=new Scanner(System.in);
         System.out.print("enter value of n1:");
         int n1=sc.nextInt();
          System.out.print("enter value of n2:");
         int n2=sc.nextInt();
          System.out.print("enter value of n3:");
         int n3=sc.nextInt();
        if(n1>n2 && n1>n3){
            if(n2>n3){
                 System.out.println("n1 is max and n3 is min ");
            }
            else{
                System.out.println("n1 is max and n2 is min ");
            }
        }
       if(n2>n1 && n2>n3){
            if(n1>n3){
                 System.out.println("n2 is max and n3 is min ");
            }
            else{
                System.out.println("n2 is max and n1 is min ");
            }
        }
        if(n3>n1 && n3>n2){
            if(n2>n1){
                 System.out.println("n3 is max and n1 is min ");
            }
            else{
                System.out.println("n1 is max and n2 is min ");
            }
        }
     
     }
}