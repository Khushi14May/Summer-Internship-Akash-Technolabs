//(1)Write a program to print the area of a rectangle of sides 2 and 3 units respectively.
//(2)Java Program to Find Cube of a Number
//(3)Java Program to Find Square of a Number
//(4)Length and breadth of a rectangle are 5 and 7 respectively. Write a program to calculate the area and perimeter of the rectangle.
//(5)Write a program to take two integer inputs from the user and print sum and product of them.
import java.io.*;
import java.util.*;
import java.net.*;
public class Assingment {
     public static void main(String[] args){
         //(1)st program Area of rectange
         int l=2;
         int b=3;
         int area=l*b;
         System.out.println("area of rectange: "+area);
         //2nd Find Cube of a Number
         Scanner sc=new Scanner(System.in);
         System.out.print("enter a number:");
         int n=sc.nextInt();
         int cube=n*n*n;
          System.out.println("Cube of a Number : "+cube);
          //3rd Find Square of a Number
         System.out.print("enter a number:");
         int num=sc.nextInt();
         int sqaure=num*num;
          System.out.println("sqaure of a Number : "+sqaure);
          //(4)st program Area and perimeter of rectange
         int L=5;
         int B=7;
         int a=L*B;
         int perimeter=L+B;
         System.out.println("area of rectange: "+a);
         System.out.println("perimeter of rectange: "+perimeter);
        // 5th print sum and product of user input number
        System.out.print("enter a first number:");
         int num1=sc.nextInt();
         System.out.print("enter a second number:");
         int num2=sc.nextInt();
         int sum=num1+num2;
         System.out.println("Sum: "+sum);
         int product=num1*num2;
         System.out.println("product: "+product);
     }
}
