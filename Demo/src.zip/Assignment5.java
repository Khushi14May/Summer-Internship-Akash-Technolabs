//Java Program to Print Even Numbers from 1 to N using For loop

import java.io.*;
import java.util.*;
import java.net.*;
public class Assignment5 {
    public static void main(String[] args){
          Scanner sc=new Scanner(System.in);
         System.out.print("enter value of n:");
         int n1=sc.nextInt();
         for(int i=1;i<=n1;i++){
             if(i%2==0){
                 System.out.println(i);
             }
         }
 }
}